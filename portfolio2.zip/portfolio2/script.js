document.addEventListener('DOMContentLoaded', () => {
  // Typing Animation
  const phrases = ['a Web Developer', 'a Designer', 'a Tech Enthusiast'];
  let i = 0, j = 0, currentPhrase = [], isDeleting = false, isEnd = false;
  const el = document.querySelector('.typing');

  function loop() {
    isEnd = false;
    el.innerHTML = currentPhrase.join('');
    if (i < phrases.length) {
      if (!isDeleting && j <= phrases[i].length) {
        currentPhrase.push(phrases[i][j]);
        j++;
        el.innerHTML = currentPhrase.join('');
      }

      if (isDeleting && j <= phrases[i].length) {
        currentPhrase.pop(phrases[i][j]);
        j--;
        el.innerHTML = currentPhrase.join('');
      }

      if (j == phrases[i].length) {
        isEnd = true;
        isDeleting = true;
        setTimeout(loop, 1000);
        return;
      }

      if (isDeleting && j === 0) {
        currentPhrase = [];
        isDeleting = false;
        i++;
        if (i === phrases.length) i = 0;
      }
    }
    setTimeout(loop, 150);
  }

  loop();

  // Form Validation
  document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();

    if (!name || !email || !message) {
      alert('Please fill out all fields.');
      return;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      alert('Enter a valid email address.');
      return;
    }

    alert('Message sent successfully!');
    this.reset();
  });

  // Project Filtering
  window.filterProjects = function(category) {
    const projects = document.querySelectorAll('.project');
    projects.forEach(project => {
      if (category === 'all' || project.classList.contains(category)) {
        project.style.display = 'block';
      } else {
        project.style.display = 'none';
      }
    });
  };

  // Dark Mode Toggle
  document.getElementById('theme-toggle').addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
  });
});
